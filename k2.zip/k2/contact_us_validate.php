<?php
	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
	$name=$_REQUEST["name"];
	$email=$_REQUEST["email"];
	$subject=$_REQUEST["subject"];
	$msg=$_REQUEST["message"];
	mysqli_query($conn,"insert into feedback (name, email, subject, message) values ('$name', '$email', '$subject', '$msg');");
	session_start();
	$_SESSION['feedback']="true";
	if(isSet($_SESSION['feedback']))
		header('Location: contact-us.php');
?>