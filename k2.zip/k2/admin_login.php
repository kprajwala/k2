<html>
<head>
<meta name="viewport" content="width=device-width", initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;
}
form {border: 2px solid #FFFFFF;}
.bg {
  background-image: url("admin_login.jpg");
  height: 86%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
input[type=text], input[type=password] {
  width: 40%;
  padding: 10px 10px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
button {
  background-color: #008080;
  color: white;
  padding: 10px 10px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 20%;
}

button:hover {
  opacity: 0.8;
}
.container {
  padding: 16px;
}
.header {
  background-color: #e6f2ff;
  padding: 20px;
  text-align: center;
  
}
.main{
	margin-left:400px;
	margin-right:400px;
	margin-top:100px;
	padding:0;
	background-color:white;
}
</style>
</head>
<body>
<center>
<div class="header">
  <h1><font color="black">O</font><font color=#009999><a href="index.php">nline Charity</a></font></h1>
</div>
<div class="bg">
<br><br>
<div class="main"><br>
<h3>Admin Login</h3>
<form method="post" action="valid.php">
  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required><br/><br/>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required><br/><br/>
    <button type="submit" name="Login">Login</button>
  </div>
  </div>
</form>
</center>
</div>
</body>
</html>
