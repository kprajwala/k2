<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="admin_login.css">
</head>
<body>

	<!-- header -->
	<header>
		<div id="search-bar">
			<div class="container">
				<div class="row">
					<form action="#" name="search" class="col-xs-12">
						<input type="text" name="search" placeholder="Type and Hit Enter"><i id="search-close" class="fa fa-close"></i>
					</form>
				</div>
			</div>
		</div>
		<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
							
									<li><a href="about-us.php">About Us</a></li>
									<li><a href="contact-us.php">Contact Us</a></li>
							
							<li>
								<a href="donor-login.php">Donor</a>
							</li>
							
							<li>
								<a href="ngo_login.php">NGO</a>
							</li>
							<li><a href="admin_login.php">Admin</a></li>
						</ul>
					</div>
					
				</div>
			</div>	
		</nav>
	</header>
	
	<br><br><br><br>
	
	<div class="contact-map-area">
		<div class="map-area" >

				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1903.4985912346517!2d78.39738676069696!3d17.41192286174319!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb96b085001d67%3A0x4f48deff88efc042!2sG.%20Narayanamma%20Institute%20of%20Technology%20and%20Science!5e0!3m2!1sen!2sin!4v1567239727381!5m2!1sen!2sin" width="1700" height="470" frameborder="0" style="border:0;" allowfullscreen=""></iframe>

		</div>
	</div>	
	
	<!-- contact wrapper -->
	<div class="contact-page-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="row">
						<div class="col-sm-4 widget">
							<h4>Address</h4>
							<i class="fa fa-map-marker"></i>
							<p>G Narayanamma Institute Of Technology And Sciences, Shaikpet,Hyderabad</p>
						</div>
						<div class="col-sm-4 widget">
							<h4>Phone</h4>
							<i class="fa fa-phone"></i>
							<p>8500227411</p>
							<p>8309576820</p>
						</div>
						<div class="col-sm-4 widget">
							<h4>E-mail</h4>
							<i class="fa fa-envelope"></i>
							<p>charityonline2020@gmail.com</p>
							<p>principal@gnits.ac.in</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="comment-form-wrapper contact-from clearfix">
						<div class="widget-title ">
							<h4>Feedback..</h4>	
						</div>
						<form class="comment-form row altered" action="contact_us_validate.php">
							<div class="field col-sm-4">
								<h4>Name</h4>
								<input type="text" name="name" required>
							</div>
							<div class="field col-sm-4">
								<h4>E-mail</h4>
								<input type="text" name="email" required>
							</div>
							<div class="field col-sm-4">
								<h4>Subject</h4>
								<input type="text" name="subject" required>
							</div>
							<div class="field col-sm-12">
								<h4>Message</h4>
								<textarea name="message" required></textarea>
							</div>
							<div class="field col-sm-4">
								<button class="btn btn-big btn-solid"><i class="fa fa-paper-plane"></i><span>Send Message</span></button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
	if((isset($_SESSION['feedback'])) && $_SESSION['feedback']=="true")
				{
					echo "Thankyou for your feedback...";
					$_SESSION['feedback']="false";
				}
	?>

	<!-- Footer -->
	<footer>
		<div class="footer-bar">
			<div class="container">
				<h5>Copyright ©2020 Online Charity System... All Rights Reserved</h5>
			</div>
		</div>
	</footer>
	<!-- Scripts -->
	<script type="text/javascript" src="assets/js/jquery2.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.meanmenu.js"></script>
	<script type="text/javascript" src="assets/js/progress-bar-appear.js"></script>
	<script type="text/javascript" src="assets/owl-carousel/owl.carousel.min.js"></script>
	<script type="text/javascript" src="assets/js/nivo-lightbox.min.js"></script>
	<script type="text/javascript" src="assets/js/isotope.min.js"></script>
	<script type="text/javascript" src="assets/js/countdown.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBEypW1XtGLWpikFPcityAok8rhJzzWRw "></script>
	<script type="text/javascript" src="assets/js/gmaps.js"></script>
	<script type="text/javascript" src="assets/js/plugins.js"></script>
	<script type="text/javascript" src="assets/js/js.js"></script>

</body>
</html>