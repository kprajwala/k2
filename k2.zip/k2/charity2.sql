-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2019 at 02:08 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `charity2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin`, `pwd`) VALUES
('charity', 'charity'),
('admin', 'admin'),
('prajwala', 'prajwala'),
('ramya', 'ramya'),
('tejasree', 'tejasree'),
('sahithya', 'sahithya');

-- --------------------------------------------------------

--
-- Table structure for table `cash_records`
--

CREATE TABLE `cash_records` (
  `d_email` varchar(255) NOT NULL,
  `cash` int(255) NOT NULL,
  `ngo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_records`
--

INSERT INTO `cash_records` (`d_email`, `cash`, `ngo`) VALUES
('kandlikarprajwala@gmail.com', 2500, 'Aadarsh Welfare Society'),
('kandlikarprajwala@gmail.com', 8200, 'Abhaya Foundation'),
('kandlikarprajwala@gmail.com', 11400, 'Yatna NGO'),
('kandlikarprajwala@gmail.com', 2598, 'Shine NGO'),
('kandlikarprajwala@gmail.com', 52800, 'Sadhana');

-- --------------------------------------------------------

--
-- Table structure for table `donor_donations`
--

CREATE TABLE `donor_donations` (
  `donor_id` int(255) NOT NULL,
  `items` varchar(255) NOT NULL,
  `ngo` varchar(30) NOT NULL,
  `d_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor_donations`
--

INSERT INTO `donor_donations` (`donor_id`, `items`, `ngo`, `d_email`) VALUES
(5, 'clothes , shoes , bike , specs , watch , blankets', 'abhaya foundation', 'kandlikarprajwala@gmail.com'),
(5, 'car , clothes , shoes , bike , blankets', 'yatna ngo', 'kandlikarprajwala@gmail.com'),
(3, 'blankets , bike', 'sadhana', 'ramya.kotha22@gmail.com'),
(5, 'blankets , bike , pens , clothes', 'Nirmaan Organization', 'kandlikarprajwala@gmail.com'),
(5, 'Hair , car , clothes , bike , fan', 'sadhana', 'kandlikarprajwala@gmail.com'),
(5, 'watch , blankets', 'Shine NGO', 'kandlikarprajwala@gmail.com'),
(5, 'shoes , bike , clothes', 'NGOs Group', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'Swayam Krishi Sangam', 'kandlikarprajwala@gmail.com'),
(5, 'car , clothes', 'Sphoorti Foundation', 'kandlikarprajwala@gmail.com'),
(5, 'shoes', 'Swecha Office', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'Youth For Seva', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'Youngistaan Foundation', 'kandlikarprajwala@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `donor_items_left`
--

CREATE TABLE `donor_items_left` (
  `d_email` varchar(255) NOT NULL,
  `items` varchar(20) NOT NULL,
  `id` int(200) DEFAULT NULL,
  `quantity` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor_items_left`
--

INSERT INTO `donor_items_left` (`d_email`, `items`, `id`, `quantity`) VALUES
('kandlikarprajwala@gmail.com', 'blankets', 5, 20),
('kandlikarprajwala@gmail.com', 'shoes', 5, 50),
('kandlikarprajwala@gmail.com', 'clothes', 5, 60),
('kandlikarprajwala@gmail.com', 'clothes`', 5, 10),
('kandlikarprajwala@gmail.com', '', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `donor_user`
--

CREATE TABLE `donor_user` (
  `id` int(255) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `d_email` varchar(50) NOT NULL,
  `d_city` varchar(50) NOT NULL,
  `d_state` varchar(50) NOT NULL,
  `d_phone_no` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor_user`
--

INSERT INTO `donor_user` (`id`, `d_name`, `d_email`, `d_city`, `d_state`, `d_phone_no`, `pwd`) VALUES
(1, 'Akash Rama', 'bunny4141@gmail.com', 'Hyderabad', 'Telangana', '738378992', 'akash'),
(2, 'Sahithya Rama', 'sahi.rama123@gmail.com', 'Hyd', 'Telangana', '8686131100', 'sahithya'),
(3, 'ramya', 'ramya.kotha22@gmail.com', 'Khammam', 'Telangana', '9133236251', 'ramya'),
(4, 'Nikhila', 'nikhilamadhari2014@gmail.com', 'Hyderabad', 'Telangana', '7093716881', 'nikhila'),
(5, 'Prajwala', 'kandlikarprajwala@gmail.com', 'Nizamabad', 'Telangana', '8500227411', 'prajwala'),
(6, 'Sony', 'prajwala1799@gmail.com', 'Hyderabad', 'Telangana', '8309576820', 'sony'),
(7, 'Prajwala Kandlikar', 'nikalpurprajwala@gmail.com', 'hyd', 'TELANGANA', '8500227411', 'prajwala'),
(8, 'TejaSree', 'tejasreereddy1998@gmail.com', 'Hyd', 'Telangana', '9493699106', 'tejasree');

-- --------------------------------------------------------

--
-- Table structure for table `d_donation_record`
--

CREATE TABLE `d_donation_record` (
  `donor_id` int(255) NOT NULL,
  `items` varchar(100) NOT NULL,
  `ngo` varchar(255) NOT NULL,
  `d_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `d_donation_record`
--

INSERT INTO `d_donation_record` (`donor_id`, `items`, `ngo`, `d_email`) VALUES
(5, 'clothes', 'abhaya foundation', 'kandlikarprajwala@gmail.com'),
(5, 'shoes', 'abhaya foundation', 'kandlikarprajwala@gmail.com'),
(5, 'bike', 'abhaya foundation', 'kandlikarprajwala@gmail.com'),
(5, 'car', 'yatna ngo', 'kandlikarprajwala@gmail.com'),
(3, 'blankets', 'sadhana', 'ramya.kotha22@gmail.com'),
(3, 'bike', 'sadhana', 'ramya.kotha22@gmail.com'),
(5, 'clothes', 'Yatna NGO', 'kandlikarprajwala@gmail.com'),
(5, 'blankets', 'Nirmaan Organization', 'kandlikarprajwala@gmail.com'),
(5, 'bike', 'Nirmaan Organization', 'kandlikarprajwala@gmail.com'),
(5, 'specs', 'abhaya foundation', 'kandlikarprajwala@gmail.com'),
(5, 'watch', 'abhaya foundation', 'kandlikarprajwala@gmail.com'),
(5, 'Hair', 'sadhana', 'kandlikarprajwala@gmail.com'),
(5, 'car', 'sadhana', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'sadhana', 'kandlikarprajwala@gmail.com'),
(5, 'bike', 'sadhana', 'kandlikarprajwala@gmail.com'),
(5, 'shoes', 'yatna ngo', 'kandlikarprajwala@gmail.com'),
(5, 'bike', 'yatna ngo', 'kandlikarprajwala@gmail.com'),
(5, 'blankets', 'abhaya foundation', 'kandlikarprajwala@gmail.com'),
(5, 'watch', 'Shine NGO', 'kandlikarprajwala@gmail.com'),
(5, 'shoes', 'NGOs Group', 'kandlikarprajwala@gmail.com'),
(5, 'bike', 'NGOs Group', 'kandlikarprajwala@gmail.com'),
(5, 'pens', 'Nirmaan Organization', 'kandlikarprajwala@gmail.com'),
(5, 'fan', 'sadhana', 'kandlikarprajwala@gmail.com'),
(5, 'blankets', 'yatna ngo', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'Nirmaan Organization', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'Swayam Krishi Sangam', 'kandlikarprajwala@gmail.com'),
(5, 'car', 'Sphoorti Foundation', 'kandlikarprajwala@gmail.com'),
(5, 'shoes', 'Swecha Office', 'kandlikarprajwala@gmail.com'),
(5, 'blankets', 'Shine NGO', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'Youth For Seva', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'NGOs Group', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'Youngistaan Foundation', 'kandlikarprajwala@gmail.com'),
(5, 'clothes', 'Sphoorti Foundation', 'kandlikarprajwala@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(40) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `subject`, `message`) VALUES
('Ramya', 'ramya.kotha22@gmail.com', 'Details', 'I need the information regarding cash donations...'),
('Prajwala', 'kandlikarprajwala@gmail.com', 'Cash Details', 'Needed information about NGO\'s....'),
('Teja', 'teja@gmail.com', 'Donation', 'Problem with the donation of cash to NGO...'),
('Sahithya Rama', 'sahithya@gmail.com', 'NGO Search..', 'NGO search details...');

-- --------------------------------------------------------

--
-- Table structure for table `ngo_donations`
--

CREATE TABLE `ngo_donations` (
  `ngo_id` int(200) NOT NULL,
  `donor_id` int(20) NOT NULL,
  `items` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo_donations`
--

INSERT INTO `ngo_donations` (`ngo_id`, `donor_id`, `items`) VALUES
(3, 5, 'clothes,shoes,blankets'),
(4, 5, 'blankets'),
(10, 5, 'shoes,bike,clothes'),
(12, 5, 'pens,clothes,blankets'),
(14, 5, 'clothes,fan'),
(15, 5, 'clothes'),
(17, 5, 'car,clothes'),
(16, 5, 'shoes'),
(5, 5, 'blankets'),
(13, 5, 'clothes'),
(11, 5, 'clothes');

-- --------------------------------------------------------

--
-- Table structure for table `ngo_donations_record`
--

CREATE TABLE `ngo_donations_record` (
  `ngo_id` int(255) NOT NULL,
  `donor_id` int(255) NOT NULL,
  `items` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo_donations_record`
--

INSERT INTO `ngo_donations_record` (`ngo_id`, `donor_id`, `items`) VALUES
(3, 5, 'clothes'),
(3, 5, 'shoes'),
(4, 5, 'blankets'),
(10, 5, 'shoes'),
(10, 5, 'bike'),
(12, 5, 'pens'),
(14, 5, 'clothes'),
(14, 5, 'fan'),
(3, 5, 'blankets'),
(12, 5, 'clothes'),
(15, 5, 'clothes'),
(12, 5, 'blankets'),
(17, 5, 'car'),
(16, 5, 'shoes'),
(5, 5, 'blankets'),
(13, 5, 'clothes'),
(10, 5, 'clothes'),
(11, 5, 'clothes'),
(17, 5, 'clothes');

-- --------------------------------------------------------

--
-- Table structure for table `ngo_login`
--

CREATE TABLE `ngo_login` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo_login`
--

INSERT INTO `ngo_login` (`id`, `name`, `email`, `phone_no`, `city`, `state`, `address`, `pwd`) VALUES
(1, 'Rama Foundations', 'rmf@gmail.com', '687687879', 'hyderabad', 'telangana', 'Banjara Hills, Santosh Nagar.', '12345'),
(2, 'Racha\'s Foundation', 'racha@gmail.com', '998745656', 'Hyderabad', 'Telangana', 'kbwkjen', '123456'),
(3, 'Yatna NGO', 'info@yatna.org', '04065527969', 'Hyderabad', 'Telangana', 'Plot No.22, Road No.2, Rao & Raju Colony, Banjara Hills', 'yatnango'),
(4, 'Abhaya Foundation', 'abhaya@abhayafoundation.org', '09959220450', 'Hyderabad', 'Telangana', '6-3-609/140/1, Anand Nagar Colony, Khairtabad, Hyderabad, Telangana 500004', 'abhaya foundation'),
(5, 'Shine NGO', 'info@shinengo.org', '9347738490', 'Hyderabad', 'Telangana', 'Flat No.#82,A.V Nagar,Extension II,Turkayamjal, HayathNagar,Hyderabad - 501510.', 'shinengo'),
(6, 'Suvidha NGO', 'info@meerad.in', '8540085000', 'Hyderabad', 'Telangana', '202, Raghava Cottage, Swarakapur Colony, Punjagutta, Punjagutta,Telangana 500082', 'suvidhanago'),
(7, 'Ashray Akruti', 'ashrayakruti@yahoo.com', '04040042250', 'Hyderabad', 'Telangana', '8-3-1027/A2, Lane, Srinagar Colony Main Rd, opp. Indian Bank,Hyderabad-500073', 'ashrayakruti'),
(8, 'Desire NGO', 'desiresociety@gmail.com', '04064581128', 'Hyderabad', 'Telangana', 'KBR Colony, Bollaram, Hyderabad, Telangana 502325', 'desirengo'),
(9, 'Sannihitha center', 'sannihitaindia@yahoo.com', '08790063904', 'Hyderabad', 'Telangana', 'Noorani Manzil, Door No. 125/2RT, Street No.5, Secunderabad, Begumpet, Hyderabad, Telangana 500016', 'sannihitacenter'),
(10, 'NGOs Group', 'support@ngosgroup.com', '074161 11101', 'Hyderabad', 'Telangana', '8-101, Srinivasa Nagar Park Rd, Srinivasa Nagar West, Chintal, Hyderabad, Telangana 500054', 'ngosgroup'),
(11, 'Youngistaan Foundation', 'arun@youngistaanfoundation.org', '09885342224', 'Hyderabad', 'Telangana', 'Flat number A 104, Badruka Enclave, Above Andhra Bank, Banjara Hills, Hyderabad, Telangana 500034', 'youngistaanfoundation'),
(12, 'Nirmaan Organization', 'contact@nirmaan.org ', '09000276903', 'Hyderabad', 'Telangana', 'Flat No. 202, House No. 916, Preethi Enclave, Rd Number 47, Ayyappa Society, Madhapur, Hyderabad, Telangana 500081', 'nirmaan organization'),
(13, 'Youth For Seva', 'contact@youthforseva.org', '07995026322', 'Hyderabad', 'Telangana', 'Opp Times of India Office, Plot No. 18, Road No. 3, Banjara Hills- 500034', 'youthforseva'),
(14, 'Sadhana', 'sadhanawelfare@gmail.com', '04023870799', 'Hyderabad', 'Telangana', 'Plot A-7/5 Road No,6, Nacharam, Opp. HP Petrol Bunk, Hyderabad, Pin: 500076', 'sadhana'),
(15, 'Swayam Krishi Sangam', 'info@sksngo.org ', '04066416919', 'Hyderabad', 'Telangana', '#8-2-608/1/1, Gaffar Khan Colony, Road No: 10, Banjarahills, 500034', 'swayamkrishisangam'),
(16, 'Swecha Office', 'contact@swecha.net', '08008503614', 'Hyderabad', 'Telangana', 'Swecha Sy. No. 91, Beside Center Svm, Jawaharlal, Nehru Outer Ring Rd, Madhava Reddy Colony, Gachibowli', 'swechaoffice'),
(17, 'Sphoorti Foundation', 'info@sphoorti.org', '09959559022', 'Hyderabad', 'Telangana', 'Survey No. 324, Dundigal Village, Gowdavelli-Dundigal Rd,500043', 'sphoortifoundation'),
(18, 'Prajwala', 'nikalpurprajwala@gmail.com', '8500227411', 'Hyderabad', 'Telangana', 'Shaikpet', 'prajwala');

-- --------------------------------------------------------

--
-- Table structure for table `ngo_req`
--

CREATE TABLE `ngo_req` (
  `ngo_id` int(200) NOT NULL,
  `req` varchar(100) NOT NULL,
  `quantity` int(20) NOT NULL,
  `priority` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo_req`
--

INSERT INTO `ngo_req` (`ngo_id`, `req`, `quantity`, `priority`) VALUES
(3, 'clothes', 20, 3),
(5, 'clothes', 10, 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donor_donations`
--
ALTER TABLE `donor_donations`
  ADD KEY `donor_id` (`donor_id`);

--
-- Indexes for table `donor_user`
--
ALTER TABLE `donor_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ngo_donations_record`
--
ALTER TABLE `ngo_donations_record`
  ADD KEY `ngo_id` (`ngo_id`),
  ADD KEY `donor_id` (`donor_id`);

--
-- Indexes for table `ngo_login`
--
ALTER TABLE `ngo_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donor_user`
--
ALTER TABLE `donor_user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ngo_login`
--
ALTER TABLE `ngo_login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `donor_donations`
--
ALTER TABLE `donor_donations`
  ADD CONSTRAINT `donor_donations_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donor_user` (`id`);

--
-- Constraints for table `ngo_donations_record`
--
ALTER TABLE `ngo_donations_record`
  ADD CONSTRAINT `ngo_donations_record_ibfk_1` FOREIGN KEY (`ngo_id`) REFERENCES `ngo_login` (`id`),
  ADD CONSTRAINT `ngo_donations_record_ibfk_2` FOREIGN KEY (`donor_id`) REFERENCES `donor_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
