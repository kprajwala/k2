<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="admin_login.css">
	<style>
		header .container{
			width:100%;
			padding:0px 40px 0px 40px;
		}
		.bg {
  background-image: url("a_ngo.jpg");
  height: 100%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.main {
  margin-left: 500px;
margin-right:500px;  /* Same width as the sidebar + left position in px */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 20px 50px 20px 50px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
.submit{
	  background:#CD5C5C;
	  color:white;
  }
	</style>
</head>
<body style="background:white">
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<li><a href="recordsNGO.php">NGO Records</a></li>
								<li><a href="recordsDonor.php">Donor Records</a></li>
								<li><a href="sendMails.php">Send emails</a></li>
								<li><a href="feedback.php">Feedback</a></li>
								<li><a href="addNgo.php">Add NGO</a></li>
								<li><a href="admin_login.php">LogOut</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header>
	<div class="bg"><br><br><br><br><br><br>
		<div class="main" style="background:white">
		<h4>NGO ADDED SUCCESSFULLY..</h4><br>
			<form action="addNgoValidate.php" method="POST">
					<b><font color="#CD5C5C"><u>ADD NGO..</u></font><br></b><br>
					<b><h4>NGO name...<input type="text" style="background:#D0D0D0" name="name" required/></b>
					<b>Phone Number...<input type="text" style="background:#D0D0D0" name="phno" required/></b>
					<b>Email...<input type="text" style="background:#D0D0D0" name="email" required/></b>
					<b>Address...<input type="textarea" style="background:#D0D0D0" name="address" required/></b>
					<b>City...<input type="text" style="background:#D0D0D0" name="city" required/></b>
					<b>State...<input type="text" style="background:#D0D0D0" name="state" required/></b>
					<b>Password...<input type="password" style="background:#D0D0D0" name="pwd" required/></b></h4>
		<input type="submit" name="submit" class="submit" value="Submit" style="padding:6px 6px 6px 6px; text-color:#ffffff"/></h2>

			</form>
			
		</div>
	</div>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$name=$_REQUEST["name"];
		$phno=$_REQUEST["phno"];
		$email=$_REQUEST["email"];
		$address=$_REQUEST["address"];
		$city=$_REQUEST["city"];
		$state=$_REQUEST["state"];
		$pwd=$_REQUEST["pwd"];
		$q="insert into ngo_login(name,email,phone_no,address,city,state,pwd) values('$name','$email','$phno','$address','$city','$state','$pwd';";
		mysqli_query($conn,$q);
		
	?>
	</body>
	</html>