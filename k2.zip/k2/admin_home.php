<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="admin_login.css">
	<style>
		header .container{
			width:100%;
			padding:0px 40px 0px 40px;
		}
	</style>
</head>
<body>

<!-- header -->
	<header>
		<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
							
									<li><a href="recordsNGO.php">NGO Records</a></li>
									<li><a href="recordsDonor.php">Donor Records</a></li>
									<li><a href="sendMails.php">Send emails</a></li>
									<li><a href="addNgo.php">Add NGO</a></li>
									<li><a href="feedback.php">Feedback</a></li>
							
							<li>
								<a href="a_logout.php">LogOut</a>
							</li>
						</ul>
					</div>
					
				</div>
			</div>	
		</nav>
	</header>

	<!-- basic-slider start -->
	<div class="slider-section">
		<div class="slider-active owl-carousel">
			<div class="single-slider slider-screen nrbop bg-black-alfa-40" style="background-image: url(assets/img/slides/s5.jpg);">
				<div class="container">
					<div class="slider-content text-white">
						<h2 class="b_faddown1 cd-headline clip is-full-width" >Charity....Humanity </h2>
						<p class="b_faddown2">The value of a man resides in what he gives and <br>not in what he is capable of receiving. </p>
						
					</div>
				</div>				
			</div>
			<div class="single-slider slider-screen nrbop bg-black-alfa-40 " style="background-image: url(assets/img/slides/s4.jpg);">
				<div class="container">
					<div class="slider-content text-white"><br><br><br>
						<h2 class="b_faddown1 cd-headline clip is-full-width" >Charity....Humanity </h2>
						<p class="b_faddown2">It's not how much we give but how much love we put into giving. 
					</div>
				</div>				
			</div>

			<div class="single-slider slider-screen nrbop bg-black-alfa-40" style="background-image: url(assets/img/slides/s3.jpg);">
				<div class="container">
					<div class="slider-content text-white">
						<h2 class="b_faddown1 cd-headline clip is-full-width" >Charity....Humanity </h2>
						<p class="b_faddown2">Think of giving not as a duty but as a privilege. </p>
					</div>
				</div>				
			</div>				
		</div>
	</div>	
	
	
	

	
	
	
	
	

	
	
	<!-- Foter -->
	<footer>
		<div class="footer-bar">
			<div class="container">
				<h5>Copyright ©2019 Online Charity System... All Rights Reserved</h5>
			</div>
		</div>
	</footer>

	<!-- Scripts -->
	<script type="text/javascript" src="assets/js/jquery2.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.meanmenu.js"></script>
	<script type="text/javascript" src="assets/js/progress-bar-appear.js"></script>
	<script type="text/javascript" src="assets/owl-carousel/owl.carousel.min.js"></script>
	<script type="text/javascript" src="assets/js/nivo-lightbox.min.js"></script>
	<script type="text/javascript" src="assets/js/isotope.min.js"></script>
	<script type="text/javascript" src="assets/js/countdown.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBEypW1XtGLWpikFPcityAok8rhJzzWRw "></script>
	<script type="text/javascript" src="assets/js/gmaps.js"></script>
	<script type="text/javascript" src="assets/js/plugins.js"></script>
	<script type="text/javascript" src="assets/js/js.js"></script>

</body>
</html>