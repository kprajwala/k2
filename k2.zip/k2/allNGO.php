<?php
	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
	$sub=$_REQUEST["subAllNGO"];
	$msg=$_REQUEST["msgAllNGO"];
	$q=mysqli_query($conn,"select * from ngo_login;");
	//echo "mails";
	while($r = $q->fetch_assoc()) {
		mail($r["email"],$sub,$msg,'From:onlinecharity2020@gmail.com');
	}
	header('Location: sendMails.php');
?>
